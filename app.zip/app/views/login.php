
<div class="form-box admin-form"  style="">


<form class="w3-container w3-card-4 w3-border" action="" method="post">

<h2 class="w3-text-blue">Login Panel</h2>
<p>Welcome to admin Panel ,This Panel is for Staff.</p>

<p>
<label class="w3-text-blue"><b>UserName</b></label>
<input class="w3-input w3-border" name="username" type="text"></p>

<p>
<label class="w3-text-blue"><b>Password</b></label>
<input class="w3-input w3-border" name="password" type="password"></p>

<p>
<input type="submit" value="Login"  class="w3-btn w3-blue" name="submit" />
</p>

</form>
</div><!--form-box-->
