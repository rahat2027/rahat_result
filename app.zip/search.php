<?php
session_start();
require_once "app/controller.php";
require_once "app/model/search.php";
require_once VIEW_PATH . "/template/header.php"; 
require_once VIEW_PATH . "/search.php"; 
require_once VIEW_PATH . "/template/footer.php"; 




