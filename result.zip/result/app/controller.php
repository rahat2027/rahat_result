<?php
# Coded By : arjun saini
# author by : arjun saini
# url: www.arjun.webege.com
define('SITEPATH','http://result.rahatfzk.org.in');
define('PATH',__DIR__);
define('VIEW_PATH',__DIR__ .'/views');
require_once"helpers/corefunctions.php";
$pdo = new PDO("mysql:host=localhost;dbname=rahatfzk_ramramg","root","");
 