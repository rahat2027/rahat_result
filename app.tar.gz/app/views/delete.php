<div class="w3-container w3-section w3-lime">
<span onclick="this.parentElement.style.display='none'" class="w3-closebtn">&times;</span>  <h3>are you sure you want to delete this?</h3>
  <form action="" method="post">
  <a href="setting.php" class="w3-btn w3-green"> back</a><input type="submit" value="Delete"  name="deletepermission" class="w3-btn w3-red">
</form></div> 