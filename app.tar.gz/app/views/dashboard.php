



<div class="w3-container w3-center">
  <h3>All Result Issued '<b><?php echo $result; ?></b>'</h3>
    <h3>All student Registerd '<b><?php echo $student; ?></b>'</h3>
</div>



</div>
      

