<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>rahat</title>
	<link rel="stylesheet" href="<?php echo SITEPATH;?>/css/lib.css" />
	<link rel="stylesheet" href="<?php echo SITEPATH;?>/css/style.css" />
	<link rel="stylesheet" href="<?php echo SITEPATH;?>/css/jquery-ui.min.css" />
	<script type="text/javascript" src="<?php echo SITEPATH; ?>/js/jquery.js"></script>
	<script type="text/javascript" src="<?php echo SITEPATH; ?>/js/jquery-ui.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		$('#cal').datepicker();
		$('#cal2').datepicker();
	});
	</script>
</head>
<body>
	
